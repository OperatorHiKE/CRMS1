import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
@ToString
public class Admin extends User{

    private String admin_name;

    public Admin(int user_id, String user_name) {
        super(user_id, user_name);
        String admin_name;
    }
}
